package com.example.demo.Service;
import com.example.demo.Dto.EmployeeDTO;
public interface EmployeeService {
	 String addEmployee(EmployeeDTO employeeDTO);
}
